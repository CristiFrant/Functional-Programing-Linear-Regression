import Helpers.print_matrix

type Mat = List[List[Double]]

class Matrix(m: Option[List[List[Double]]]) {

  def transpose: Matrix = {
    // Implementare "inspirata" din cursul 06
    def auxTranspose(mat: Mat): Mat =
      mat match {
        case Nil :: _ => Nil
        case _ => mat.map(_.head) :: auxTranspose(mat.map(_.tail))
      }

    data match
      case Some(value) => Matrix(auxTranspose(value))
      case None => Matrix(None)
  }
  def map(f: Double => Double): Matrix = {
    data match
      case Some(value) => Matrix(value.map(_.map(f)))
      case None => Matrix(None)
  }
  def *(other: Matrix): Matrix = {
    if (data.isEmpty || other.data.isEmpty || width != other.height)
      return Matrix(None)
    val trans = other.transpose
    // Functie auxiliara care calculeaza inmultirea pentru fiecare element al matricii
    def matrixItem(vec1: List[Double], vec2: List[Double]): Double =
      vec1.zip(vec2).map(_ * _).sum

    // Functie auxiliara care aplica inmultirea separat pentru fiecare coloana
    def calculateRow(row: List[Double]): List[Double] =
      trans.data.get.map(matrixItem(row, _))

    Matrix(Some(data.get.map(calculateRow)))
  }
  def ++(x: Double): Matrix = {
    if (data.isEmpty)
      return Matrix(None)

    // Functie auxiliara care adauga elementul x la finalul fiecarui rand
    def addLast(row: List[Double]): List[Double] = {
      row match
        case ::(head, next) => head :: addLast(next)
        case Nil => x :: Nil
    }

    Matrix(Some(data.get.map(addLast)))
  }
  def -(other: Matrix): Matrix = {
    if (data.isEmpty || other.data.isEmpty ||
      height != other.height || width != other.width)
      return Matrix(None)
    Matrix(Some(data.get.zip(other.data.get)
      .map(_.zip(_).map(_ - _))))
  }

  def data: Option[Mat] = this.m
  def height: Option[Int] = {
    data match
      case Some(value) => Some(value.size)
      case None => None
  }
  def width: Option[Int] = {
    data match
      case Some(value) => Some(value.head.size)
      case None => None
  }
  override def toString: String = print_matrix(data.get)
}

object Matrix {

  def apply(data: Mat): Matrix =
    data match
      case ::(head, next) => new Matrix(Some(data))
      case Nil => new Matrix(None)

  def apply(data: Option[Mat]): Matrix =
    data match
      case Some(value) => Matrix(value)
      case None => new Matrix(None)

  def apply(dataset: Dataset): Matrix = {
    try {
      val mat = dataset.getRows.map(_.map(_.toDouble))
      Matrix(mat)
    }
    catch
      case _ => Matrix(None)
  }
}
