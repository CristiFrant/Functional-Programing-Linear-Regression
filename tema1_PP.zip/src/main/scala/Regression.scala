import scala.math.abs

object Regression {

  def regression(dataset_file: String,
                attribute_columns: List[String],
                value_column: String,
                test_percentage: Double,
                alpha: Double,
                gradient_descent_steps: Int): (Matrix, Double) = {
    val dataset = Dataset(dataset_file).selectColumns(value_column :: attribute_columns)
    val (trainDs, testDs) = dataset.split(test_percentage)
    val trainMat = Matrix(trainDs.selectColumns(attribute_columns)) ++ 1
    val realValues = Matrix(trainDs.selectColumn(value_column))
    val testMat = Matrix(testDs.selectColumns(attribute_columns)) ++ 1
    val realTestVAlues = Matrix(testDs.selectColumn(value_column))
    val W = Matrix(List.fill(trainMat.width.get)(List.fill(1)(0.0)))

    def gradientDescent(W: Matrix, steps: Int): Matrix = {
      if (steps == 0) W
      else {
        val error = realValues - (trainMat * W)
        val grad = (trainMat.transpose * error).map(_ / trainMat.height.get * alpha)
        gradientDescent(W - grad.map(-_), steps - 1)
      }
    }

    val estimate = gradientDescent(W, gradient_descent_steps)
    val predictions = testMat * estimate
    val error = (realTestVAlues - predictions).map(abs).data.get.head.foldRight(0.0)(_ + _)
      / realTestVAlues.width.get
    (estimate, error)
  }

  def main(args: Array[String]): Unit = {
    print(regression("datasets/houseds.csv", List("GrLivArea", "YearBuilt"), "SalePrice", 0.1, 1e-7, 10000))
  }
}