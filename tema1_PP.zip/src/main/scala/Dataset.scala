import scala.io.Source
import Helpers.print_matrix

import scala.math.ceil

class Dataset(m: List[List[String]]) {
  val data: List[List[String]] = m
  override def toString: String = print_matrix(data)

  def selectColumn(col: String): Dataset = {
    def searchColumn(ds: List[List[String]]): List[List[String]] = {
      if(ds.head.isEmpty) ds
      // Daca prima coloana este cea pe care o cautam, intoarcem doar coloana aia
      else if (ds.head.head == col) ds.map(_.head :: Nil)
      // In caz contrar, cautam incercam urmatoarea coloana
      else searchColumn(ds.map(_.tail))
    }

    Dataset(searchColumn(data))
  }
  def selectColumns(cols: List[String]): Dataset = {
    def searchColumns(acc: List[List[String]], cols: List[String])
    : List[List[String]] = {
      if (cols.nonEmpty) searchColumns(acc.zip(selectColumn(cols.head).data)
        .map(_ ++ _), cols.tail)
      else acc
    }
    Dataset(searchColumns(selectColumn("").data, cols))
  }
  def split(percentage: Double): (Dataset, Dataset) = {
    val sorted = data.tail.sortBy(_.head)
    val step: Int = ceil(1 / percentage).toInt
    def auxSplit(test: List[List[String]], train: List[List[String]],
                 acc: List[List[String]], count: Int)
    : (List[List[String]], List[List[String]]) = {
      if (acc.isEmpty) return (test, train)
      // Daca am atins numarul de pasi, adaugam un rand la teste
      if (count == step) auxSplit(test :+ acc.head, train, acc.tail, 1)
      // Altfel, adaugam un rand la setul de antrenare
      else auxSplit(test, train :+ acc.head, acc.tail, count + 1)
    }
    val (ds2, ds1) = auxSplit(List.empty[List[String]], List.empty[List[String]],
      sorted, 1)
    (Dataset(getHeader :: ds1), Dataset(getHeader :: ds2))
  }

  def size: Int = data.length - 1
  def getRows: List[List[String]] = data.tail
  def getHeader: List[String] = data.head
}

object Dataset {
  def apply(csv_filename: String): Dataset = {
    val source = Source.fromFile(csv_filename)
    val iter = source.getLines().toList
    source.close()

    Dataset(iter.map(_.split(",").toList))
  }
  def apply(ds: List[List[String]]): Dataset = {
    new Dataset(ds)
  }
}
