object Helpers {
  def print_matrix[A](data: List[List[A]]): String = {
    data.map(_.map(_.toString).mkString(",")).mkString("\n")
  }
}